import React, { useState } from "react";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import "./App.css";
import Header from "./components/Header";
import Footer from "./components/Footer";
import Home from "./Pages/Home";
import ProductListing from "./Pages/ProductListing";
import { ProductDetails } from "./Pages/ProductDetails";
import { createContext } from "react";

import Button from '@mui/material/Button';
import Dialog from '@mui/material/Dialog';
import DialogContent from '@mui/material/DialogContent';
import { ProductZoom } from "./components/ProductZoom";
import {IoCloseSharp} from "react-icons/io5";


const MyContext =createContext();

function App() {
  const [openProductDetailModal, setOpenProductDetailModal] = useState(false);
  const [maxWidth, setMaxWidth] = useState("xs")

  const handleClickOpenProductDetailModal = () => {
    setOpenProductDetailModal(true);
  };

  const handleCloseProductDetailModal = () => {
    setOpenProductDetailModal(false);
  };



  const values = {

  }

  return (
    <>
      <BrowserRouter>
      <MyContext.Provider values={values}>
        <Header />
        <Routes>
          <Route path={"/"} exact={true} element={<Home />} />
          <Route path={"/productListing"} exact={true} element={<ProductListing />} />
          <Route path={"/product/:id"} exact={true} element={<ProductDetails />} />
        </Routes>
        <Footer />
        </MyContext.Provider>
      </BrowserRouter>

      <Dialog
        open={openProductDetailModal}
        onClose={handleCloseProductDetailModal}
        aria-labelledby="alert-dialog-title"
        aria-describedby="alert-dialog-description"
        className="productDetailModal"
      >
        <DialogContent>
          <div className="flex items-center w-full productDetailModalContainer">
            <Button className="!w-[40px] !h-[40px] !min-w-[40px] !rounded-full !text-[#000] !absolute top-[0px] right-[0px]" onClick={handleCloseProductDetailModal}><IoCloseSharp/></Button>
            <div className="col1 w-[40%]">
              <ProductZoom/>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
};

export default App;
