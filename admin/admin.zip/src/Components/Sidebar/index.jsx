import React, { useContext } from "react";
import Button from "@mui/material/Button";
import { Link } from "react-router-dom";
import { RxDashboard } from "react-icons/rx";
import { FaRegImage } from "react-icons/fa";
import { FiUsers } from "react-icons/fi";
import { RiProductHuntLine } from "react-icons/ri";
import { TbCategory } from "react-icons/tb";
import { IoBagCheckOutline } from "react-icons/io5";
import { IoMdLogOut } from "react-icons/io";
import { FaAngleDown } from "react-icons/fa6";
import { Collapse } from "react-collapse";
import { MyContext } from "../../App";

const Sidebar = () => {

  const [subMenuIndex, setSubMenuIndex] = React.useState(false);
  const isOpenSubMenu = (index) => {
    if (subMenuIndex === index) {
      setSubMenuIndex(null)
    } else {
      setSubMenuIndex(index);
    }
  }

  const Context = useContext(MyContext);

  return (
    <>
      <div className={`sidebar fixed top-0 left-0 bg-white h-full border-r border-gray-300 py-2 px-3 ${Context.isSidebarOpen ? 'w-1/6' : 'w-0'}`}>
        <div className="py-2 w-full">
          <Link to="/"><img src="http://ecme-react.themenate.net/img/logo/logo-light-full.png" className="w-[110px]" /></Link>
        </div>


        <ul className="mt-4">
          <li>
            <Link to="/">
              <Button className="w-full capitalize justify-start flex gap-3 text-sm
         text-gray-800 font-medium items-center py-2 hover:bg-gray-100"><RxDashboard className="text-lg" />
                <span>Dashboard</span></Button>
            </Link>
          </li>


          <li>
            <Button className="w-full capitalize justify-start flex gap-3 text-sm
         text-gray-800 font-medium items-center py-2 hover:bg-gray-100" onClick={() => isOpenSubMenu(1)}>
              <FaRegImage className="text-lg" /><span>Home Slider</span>
              <span className="ml-auto w-8 h-8 flex items-center justify-center">
                <FaAngleDown className={`transition-all duration-300 ${subMenuIndex === 1 ? 'rotate-180' : ''}`} />
              </span>
            </Button>


            <Collapse isOpened={subMenuIndex === 1 ? true : false}>
              <ul className="w-full">
                <li className="w-full">
                  <Button className="text-gray-700 capitalize justify-start w-full text-xs font-medium pl-9 flex gap-3">
                    <span className="block w-1 h-1 rounded-full bg-gray-400">
                    </span>{" "}
                    Home Banner List
                  </Button>
                </li>

                <li className="w-full">
                  <Button className="text-gray-700 capitalize justify-start w-full text-xs font-medium pl-9 flex gap-3">
                    <span className="block w-1 h-1 rounded-full bg-gray-400">
                    </span>
                    Add Home Banner Slide
                  </Button>
                </li>

              </ul>
            </Collapse>

          </li>


          <li>
            <Link to="/users">
              <Button className="w-full capitalize justify-start flex gap-3 text-sm
         text-gray-800 font-medium items-center py-2 hover:bg-gray-100">
                <FiUsers className="text-lg" /><span>User</span>
              </Button>
            </Link>
          </li>

          <li>
            <Button className="w-full capitalize justify-start flex gap-3 text-sm
         text-gray-800 font-medium items-center py-2 hover:bg-gray-200"
              onClick={() => isOpenSubMenu(3)}>
              <RiProductHuntLine className="text-lg" /><span>Products</span>
              <span className="ml-auto w-8 h-8 flex items-center justify-center">
                <FaAngleDown className={`transition-all duration-300 ${subMenuIndex === 3 ? 'rotate-180' : ''}`} />
              </span>
            </Button>


            <Collapse isOpened={subMenuIndex === 3 ? true : false}>
              <ul className="w-full">
                <li className="w-full">
                  <Link to="/products">
                  <Button className="text-gray-700 capitalize justify-start w-full text-xs font-medium pl-9 flex gap-3">
                    <span className="block w-1 h-1 rounded-full bg-gray-400">
                    </span>{" "}
                    Product List
                  </Button>
                  </Link>
                </li>

                <li className="w-full">
                  <Link to="/product/upload">
                  <Button className="text-gray-700 capitalize justify-start w-full text-xs font-medium pl-9 flex gap-3">
                    <span className="block w-1 h-1 rounded-full bg-gray-400">
                    </span>
                    Product Upload
                  </Button>
                  </Link>
                </li>

              </ul>
            </Collapse>
          </li>

          <li>
            <Button className="w-full capitalize justify-start flex gap-3 text-sm
         text-gray-800 font-medium items-center py-2 hover:bg-gray-200"
              onClick={() => isOpenSubMenu(4)}>
              <TbCategory className="text-lg" /><span>Category</span>
              <span className="ml-auto w-8 h-8 flex items-center justify-center">
                <FaAngleDown className={`transition-all duration-300 ${subMenuIndex === 4 ? 'rotate-180' : ''}`} />
              </span>
            </Button>


            <Collapse isOpened={subMenuIndex === 4 ? true : false}>
              <ul className="w-full">
                <li className="w-full">
                  <Link to="/categories">
                  <Button className="text-gray-700 capitalize justify-start w-full text-xs font-medium pl-9 flex gap-3">
                    <span className="block w-1 h-1 rounded-full bg-gray-400">
                    </span>{" "}
                    Category List
                  </Button>
                  </Link>
                </li>

                <li className="w-full">
                  <Link to="/categories/add">              
                      <Button className="text-gray-700 capitalize justify-start w-full text-xs font-medium pl-9 flex gap-3">
                    <span className="block w-1 h-1 rounded-full bg-gray-400">
                    </span>
                    Add a Category
                  </Button>
                  </Link>
                </li>

                <li className="w-full">
                  <Link to="/categories/subCat">
                  <Button className="text-gray-700 capitalize justify-start w-full text-xs font-medium pl-9 flex gap-3">
                    <span className="block w-1 h-1 rounded-full bg-gray-400">
                    </span>
                    Sub Category List
                  </Button>
                    </Link>
                </li>

                <li className="w-full">
                  <Link to="/categories/subCat/add">
                  <Button className="text-gray-700 capitalize justify-start w-full text-xs font-medium pl-9 flex gap-3">
                    <span className="block w-1 h-1 rounded-full bg-gray-400">
                    </span>
                    Add a Sub Category
                  </Button>
                  </Link>
                </li>
              </ul>
            </Collapse>
          </li>

          <li>
            <Link to="/orders">
            <Button className="w-full capitalize justify-start flex gap-3 text-sm
         text-gray-800 font-medium items-center py-2 hover:bg-gray-100">
              <IoBagCheckOutline className="text-xl" /><span>Orders</span>
            </Button>
            </Link>
          </li>

          <li>
            <Button className="w-full capitalize justify-start flex gap-3 text-sm
         text-gray-800 font-medium items-center py-2 hover:bg-gray-100">
              <IoMdLogOut className="text-xl" /><span>Logout</span>
            </Button></li>


        </ul>

      </div>
    </>
  )
}

export default Sidebar;