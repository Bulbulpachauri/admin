import React from 'react';

const Products = () => {
  return (
    <div>
      <h1>Products Page</h1>
    </div>
  );
};

export default Products;