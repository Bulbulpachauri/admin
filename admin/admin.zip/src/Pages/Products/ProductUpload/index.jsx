import React from 'react';

const ProductUpload = () => {
  return (
    <div>
      <h1>Product Upload Page</h1>
    </div>
  );
};

export default ProductUpload;