import React from 'react';

const Users = () => {
  return (
    <div>
      <h1>Users Page</h1>
    </div>
  );
};

export default Users;