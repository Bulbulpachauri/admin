export const rows = [
  {
    id: 1,
    name: 'Product 1',
    category: 'Category A',
    price: 100,
    sales: 50,
  },
  {
    id: 2,
    name: 'Product 2',
    category: 'Category B',
    price: 200,
    sales: 100,
  },
  {
    id: 3,
    name: 'Product 3',
    category: 'Category A',
    price: 150,
    sales: 75,
  },
  {
    id: 4,
    name: 'Product 4',
    category: 'Category C',
    price: 250,
    sales: 125,
  },
  {
    id: 5,
    name: 'Product 5',
    category: 'Category B',
    price: 300,
    sales: 150,
  },
];