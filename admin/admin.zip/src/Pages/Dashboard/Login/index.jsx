import React from 'react'

const Login = () => {
  return (
    <section>
      <h1>Login Page</h1>
    </section>
  )
}


export default Login;